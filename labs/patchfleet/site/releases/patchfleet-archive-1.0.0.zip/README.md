# Patchfleet Archive 1.0.0

Pack and restore ordered patch files using source already present in your Git clones.
Install Python 3.10 or later, Git and the zstd CLI on PATH. The published byte counts
use zstd 1.5.7. Run `python3 bundle.py --version` to check your copy.

Put each clone at `clones/OWNER/REPOSITORY`. Create a JSON list named tasks.json.
Replace COMMIT with the full base commit hash and set the paths to your patch files.
Patch paths are relative to tasks.json. Their order determines the restored filenames.

```json
[{"repo":"OWNER/REPOSITORY","commit":"COMMIT","patches":["first.patch","second.patch"]}]
```

```sh
python3 bundle.py pack clones tasks.json review.pfw
python3 bundle.py unpack clones review.pfw restored
cmp first.patch restored/000000.patch
cmp second.patch restored/000001.patch
```

The output archive and restore directory must be new. Preserve the listed Git objects for
as long as the archive is retained. Keep submitter identity and other run metadata separately.
For a self-contained archive, pack with `--mode raw`. For source-backed archives the default
tries one column encoding at level 19. Use `--level 12` for speed, `--level 22` for smaller
transfers, or `--mode auto` to try all four representations at the chosen level.

[Source and benchmark](https://github.com/pgg898200-ship-it/backfold/tree/release/patchfleet-archive-1.0.0/labs/patchfleet)
